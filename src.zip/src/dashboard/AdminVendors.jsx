import { useClient } from "./ClientContext";
import API_BASE_URL from "../config/Api";
import { useEffect, useState } from "react";
import axios from "axios";
import mammoth from "mammoth";
import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf";

// 👇 Add this line to set the worker source
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;


import CommonTable from "../components/CommonTable";

const fileBaseURL = API_BASE_URL.replace(/\/api$/, "") + "/uploads/";

const columns = [
    { key: "ClientId", label: "Client ID" },
    { key: "vendorcode", label: "Vendor Code" },
    { key: "vendorcompanyname", label: "Company Name" },
    {
        key: "Full name",
        label: "Name",
        render: (_, row) =>
            [row.Fname, row.Lname].filter(Boolean).join(" ")
    },
    { key: "Email", label: "Email" },
    { key: "Mobile", label: "Mobile" },
    {
        key: "profileImage",
        label: "Profile Image",
        type: "image",
        render: (val) =>
            val ? (
                <img
                    src={fileBaseURL + val}
                    alt=""
                    style={{ width: 50, height: 50, borderRadius: "50%" }}
                />
            ) : (
                "N/A"
            )
    },
    {
        key: "docx",
        label: "Document",
        type: "file",
        render: (val) =>
            val ? (
                <a
                    href={fileBaseURL + val}
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    View
                </a>
            ) : (
                "N/A"
            )
    },
    {
        key: "matchedKeywords",
        label: "Keywords Found",
        render: (val) =>
            val && val.length ? (
                <ul style={{ paddingLeft: 16 }}>
                    {val.map((kw, idx) => (
                        <li key={idx}>
                            <span className="badge bg-success">{kw}</span>
                        </li>
                    ))}
                </ul>
            ) : (
                "None"
            )
    }
];

export default function AdminVendors() {
    const { getAdminDetails } = useClient();
    const [vendors, setVendors] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchDocText = async (url) => {
        const fileExt = url.split('.').pop().toLowerCase();

        try {
            const response = await fetch(url);
            const buffer = await response.arrayBuffer();

            if (fileExt === "docx") {
                const result = await mammoth.extractRawText({ arrayBuffer: buffer });
                return result.value.toLowerCase();
            } else if (fileExt === "pdf") {
                const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;
                let fullText = "";

                for (let i = 1; i <= pdf.numPages; i++) {
                    const page = await pdf.getPage(i);
                    const content = await page.getTextContent();
                    const pageText = content.items.map(item => item.str).join(" ");
                    fullText += pageText + "\n";
                }

                return fullText.toLowerCase();
            } else if (fileExt === "txt") {
                const text = await response.text();
                return text.toLowerCase();
            } else {
                console.warn("Unsupported file type:", fileExt);
                return "";
            }
        } catch (err) {
            console.error("Error extracting text from document:", err);
            return "";
        }
    };

    useEffect(() => {
        const clientId = getAdminDetails?.ClientId;

        if (!clientId) {
            setError("Client ID not available.");
            setLoading(false);
            return;
        }

        const fetchVendors = async () => {
            try {
                const response = await axios.get(
                    `${API_BASE_URL}/vendors/searchVendor/${clientId}`,
                    {
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem("token")}`
                        }
                    }
                );

                const data = Array.isArray(response.data)
                    ? response.data
                    : [response.data];

                const enriched = await Promise.all(
                    data.map(async (vendor) => {
                        if (vendor.docx) {
                            const fileUrl = fileBaseURL + vendor.docx;
                            const docText = await fetchDocText(fileUrl);
                            return { ...vendor, docText }; // save full document text
                        }
                        return { ...vendor, docText: "" };
                    })
                );


                setVendors(enriched);
            } catch (err) {
                console.error("Failed to fetch vendors:", err);
                if (err.response?.status === 401) {
                    setError("Unauthorized. Please log in again.");
                } else {
                    setError(
                        err.response?.data?.message || "Failed to load vendors."
                    );
                }
            } finally {
                setLoading(false);
            }
        };

        fetchVendors();
    }, [getAdminDetails]);

    const filteredVendors = vendors.filter((vendor) => {
        if (!searchTerm.trim()) return true;
        const terms = searchTerm.toLowerCase().split(/[\s,]+/);
        return terms.some((term) => vendor.docText?.includes(term));
    });



    return (
        <div className="container mt-5">
            <h2>Admin Vendors</h2>

            {loading && <div>Loading vendors...</div>}
            {error && <div className="alert alert-danger">{error}</div>}

            {!loading && !error && (
                <>
                    <div className="mb-3">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search keywords in document (e.g. invoice, vendor)"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>

                    <CommonTable
                        columns={columns}
                        data={filteredVendors}
                    />
                </>
            )}
        </div>
    );
}