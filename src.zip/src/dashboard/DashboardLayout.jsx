import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from '../components/Header';
import ClientContext from './ClientContext';

export default function DashboardLayout() {
  const location = useLocation();
  let SendClientId = location.state?.SendClientId;

  if (!SendClientId) {
    SendClientId = localStorage.getItem("SendClientId");
  } else {
    localStorage.setItem("SendClientId", SendClientId);
  }

  console.log("Client ID from DashboardLayout:", SendClientId);

  return (
    <>
      <Header />
      <div className="dashboard-layout d-flex">
        <ClientContext.Provider value={SendClientId}>
          <Sidebar />
          <div className="main-content flex-grow-1 p-4">
            <Outlet />
          </div>
        </ClientContext.Provider>
      </div>
    </>
  );
}