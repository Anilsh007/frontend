export default function DashboardHome() {
  return (
    <div className="page">
      <h2>Dashboard Home</h2>
      <p>Welcome to your dashboard. Here’s an overview of your data.</p>
    </div>
  );
}
