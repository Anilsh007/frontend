export default function Profile() {

  return (
    <>
      <div className="page">
        <h2>Profile</h2>
        <p>Manage your profile settings here.</p>
      </div>
    </>
  );
}
