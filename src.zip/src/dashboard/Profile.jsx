// src/pages/Profile.jsx
import { useContext, useEffect, useState } from 'react';
import ClientContext from './ClientContext';
import API_BASE_URL from '../config/Api';
import CommonForm from '../components/CommonForm';
import Header from '../components/Header';

export default function Profile() {
  const SendClientId = useContext(ClientContext);
  console.log("Client ID in Profile:", SendClientId);
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    if (SendClientId) {
      fetch(`${API_BASE_URL}/client-admins/${SendClientId}`)
        .then((res) => res.json())
        .then((data) => setProfileData(data))
        .catch((err) => console.error('Error fetching profile:', err));
    }
  }, [SendClientId]);

  return (
    <>
      <div className="container mt-4">
        {profileData ? (
          <CommonForm data={profileData} />
        ) : (
          <p>Loading profile...</p>
        )}
      </div>
    </>
  );
}
