export default function Profile() {
    return (
      <div className="page">
        <h2>Your Profile</h2>
        <p>Manage your personal information here.</p>
      </div>
    );
  }
  