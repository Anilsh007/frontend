export default function Settings() {
    return (
      <div className="page">
        <h2>Settings</h2>
        <p>Adjust your preferences and settings.</p>
      </div>
    );
  }
  