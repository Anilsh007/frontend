import React, { useEffect, useState } from 'react';
import '../../styles/index.scss';
import { PiUserCirclePlus } from "react-icons/pi";
import { LiaEdit } from "react-icons/lia";
import { RiDeleteBinLine } from "react-icons/ri";

const AddClient = () => {
    const [admins, setAdmins] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [formError, setFormError] = useState('');

    const initialForm = {
        ClientId: '',
        CompanyName: '',
        FirstName: '',
        LastName: '',
        AdminEmail: '',
        Password: '',
        Address1: '',
        Address2: '',
        AboutUs: '',
        City: '',
        State: '',
        ZipCode: '',
        Phone: '',
        Mobile: '',
        Question: '',
        Answer: '',
        LicenseQty: '',
        Type: ''
    };

    const [formData, setFormData] = useState(initialForm);
    const [editIndex, setEditIndex] = useState(null);

    const fetchAdmins = () => {
        setLoading(true);
        fetch('https://api.cvcsem.com/api/client-admins')
            .then((res) => res.json())
            .then((data) => {
                if (Array.isArray(data)) {
                    setAdmins(data);
                    setError(null);
                } else {
                    setError('Unexpected data format from API');
                }
            })
            .catch((err) => setError('Error fetching client admins: ' + err.message))
            .finally(() => setLoading(false));
    };

    useEffect(() => {
        fetchAdmins();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setFormError('');

        const method = editIndex === null ? 'POST' : 'PUT';
        const url = editIndex === null
            ? 'https://api.cvcsem.com/api/client-admins'
            : `https://api.cvcsem.com/api/client-admins/${admins[editIndex].id}`;

        fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        })
            .then(async (res) => {
                const data = await res.json();
                if (!res.ok) {
                    throw new Error(data.message || 'Failed to save data');
                }
                return data;
            })
            .then(() => {
                fetchAdmins();
                closeModal();
            })
            .catch((err) => {
                setFormError(err.message);
            });
    };

    const handleDelete = (index) => {
        if (!window.confirm('Are you sure you want to delete this admin?')) return;

        const id = admins[index].id;

        fetch(`https://api.cvcsem.com/api/client-admins/${id}`, {
            method: 'DELETE'
        })
            .then((res) => {
                if (!res.ok) throw new Error('Failed to delete admin');
                fetchAdmins();
            })
            .catch((err) => alert(err.message));
    };

    const openModalForCreate = () => {
        setFormData(initialForm);
        setEditIndex(null);
        setFormError('');
        setShowModal(true);
    };

    const openModalForEdit = (index) => {
        setFormData(admins[index]);
        setEditIndex(index);
        setFormError('');
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
        setFormError('');
        setFormData(initialForm);
        setEditIndex(null);
    };

    const getFieldType = (field) => {
        const lower = field.toLowerCase();

        if (lower.includes('email')) return 'email';
        if (['licenseqty', 'zipcode', 'phone', 'mobile', 'type'].includes(lower)) return 'number';
        if (['aboutus', 'address1', 'address2'].includes(lower)) return 'textarea';
        return 'text';
    };

    return (
        <div className="container-fluid mt-4">
            <div className="d-flex justify-content-between mt-4 mb-3">
                <h3 className="text-primary">All Admins</h3>
                <button className="btn btn-outline-primary rounded-pill" onClick={openModalForCreate}>
                    Add clientAdmins <PiUserCirclePlus />
                </button>
            </div>

            {error && <div className="alert alert-danger">{error}</div>}

            {loading ? (
                <p>Loading admins...</p>
            ) : (
                <>
                    <div className="table-responsive">
                        <table className="table table-bordered table-hover clientTable">
                            <thead className="table-dark">
                                <tr>
                                    {admins.length > 0 && Object.keys(admins[0])
                                        .filter((key) => key !== 'Password')
                                        .map((key) => <th key={key}>{key}</th>)}
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {admins.map((admin, index) => (
                                    <tr key={admin.id || index}>
                                        {Object.keys(admin)
                                            .filter((key) => key !== 'Password')
                                            .map((key) => (
                                                <td key={key} title={admin[key]}>{admin[key]}</td>
                                            ))}
                                        <td className="action-btn">
                                            <button className="btn btn-outline-primary" onClick={() => openModalForEdit(index)}>
                                                <LiaEdit />
                                            </button>
                                            <button className="btn btn-outline-danger" onClick={() => handleDelete(index)}>
                                                <RiDeleteBinLine />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                {admins.length === 0 && (
                                    <tr>
                                        <td colSpan="100%">No client admins found.</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>

                    {/* Modal */}
                    {showModal && (
                        <div
                            className="modal fade show"
                            style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}
                            tabIndex="-1"
                            role="dialog"
                        >
                            <div className="modal-dialog modal-xl modal-dialog-scrollable" role="document">
                                <div className="modal-content overflow-auto">
                                    <div className="modal-header">
                                        <h5 className="modal-title">
                                            {editIndex === null ? 'Add New Client Admin' : 'Edit Client Admin'}
                                        </h5>
                                        <button type="button" className="btn-close" aria-label="Close" onClick={closeModal}></button>
                                    </div>
                                    <form onSubmit={handleSubmit}>
                                        <div className="modal-body">
                                            {formError && (
                                                <div className="alert alert-danger">{formError}</div>
                                            )}
                                            <div className="row g-2">
                                                {Object.keys(initialForm).map((field) => {
                                                    const type = getFieldType(field);
                                                    return (
                                                        <div className="col-md-4" key={field}>
                                                            <label className="form-label">{field}</label>
                                                            {type === 'textarea' ? (
                                                                <textarea
                                                                    className="form-control"
                                                                    name={field}
                                                                    value={formData[field] || ''}
                                                                    onChange={handleChange}
                                                                    required={field !== 'Address2' && field !== 'AboutUs'}
                                                                    rows={3}
                                                                />
                                                            ) : (
                                                                <input
                                                                    type={type}
                                                                    className="form-control"
                                                                    name={field}
                                                                    value={formData[field] || ''}
                                                                    onChange={handleChange}
                                                                    required={field !== 'Address2' && field !== 'AboutUs'}
                                                                    autoComplete="off"
                                                                />
                                                            )}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                        <div className="modal-footer">
                                            <button type="submit" className="btn btn-success">
                                                {editIndex === null ? 'Create' : 'Update'}
                                            </button>
                                            <button type="button" className="btn btn-secondary" onClick={closeModal}>
                                                Cancel
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

export default AddClient;