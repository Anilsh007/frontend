import React, { useState } from 'react';
import axios from 'axios';

export default function LoginRegister() {
    const [formData, setFormData] = useState({
        vendorcode: '',
        vendorcompanyname: '',
        Fname: '',
        Lname: '',
        Email: '',
        Address1: '',
        Address2: '',
        City: '',
        State: '',
        ZipCode: '',
        Samuin: '',
        Fein: '',
        Duns: '',
        Naics1: '',
        Naics2: '',
        Naics3: '',
        Naics4: '',
        Naics5: '',
        Nigp1: '',
        Nigp2: '',
        Nigp3: '',
        Nigp4: '',
        Nigp5: '',
        Phone: '',
        Mobile: '',
        Sbclass: '',
        Class: '',
        UserId: '',
        Password: '',
        SecQuestion: '',
        SecAnswer: '',
        Aboutus: '',
        Type: '2'
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleRegister = async () => {
        try {
            const response = await axios.post('https://api.cvcsem.com/api/vendors', formData);
            alert('Vendor registered successfully!');
            document.getElementById('registerModalClose').click();
        } catch (error) {
            console.error(error);

            // Check if backend sent a message in response
            if (error.response && error.response.data) {
                // Show backend error message
                alert('Error: ' + (error.response.data.message || JSON.stringify(error.response.data)));
            } else {
                // Fallback generic message
                alert('Failed to register vendor.');
            }
        }
    };


    return (
        <>
            <div className="LRbox d-flex justify-content-around p-4">
                <div className="box text-center border p-3 rounded">
                    <h3>New Vendor Registration</h3>
                    <p><strong>Register your company</strong></p>
                    <button className="btn btn-outline-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#registerModal">REGISTER</button>
                </div>

                <div className="box text-center border p-3 rounded">
                    <h3>Login</h3>
                    <form>
                        <label>Username :</label>
                        <input type="text" className="form-control mb-2" placeholder="Enter Username" />
                        <label>Password :</label>
                        <input type="password" className="form-control mb-2" placeholder="Enter Password" />
                        <button className="btn btn-outline-primary rounded-pill" type="submit">LOG IN</button>
                    </form>
                    <a href="#" className="d-block mt-2">Forgot Password? Click Here</a>
                </div>
            </div>

            {/* Modal */}
            <div className="modal fade" id="registerModal" tabIndex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
                <div className="modal-dialog modal-xl modal-dialog-scrollable">
                    <div className="modal-content p-3">
                        <div className="modal-header">
                            <h5 className="modal-title" id="registerModalLabel">Vendor Registration</h5>
                            <button id="registerModalClose" type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="row g-3">
                                {[
                                    "vendorcode", "vendorcompanyname", "Fname", "Lname", "Email", "Password", "Address1", "Address2", "Aboutus", "City", "State", "ZipCode", "Samuin", "Fein", "Duns", "Naics1", "Naics2", "Naics3",
                                    "Naics4", "Naics5", "Nigp1", "Nigp2", "Nigp3", "Nigp4", "Nigp5", "Phone", "Mobile",
                                    "Sbclass", "Class", "UserId", "SecQuestion", "SecAnswer"
                                ].map((field, index) => (
                                    <div className="col-md-4" key={index}>
                                        <label className="form-label">{field}</label>
                                        {["Aboutus", "Address1", "Address2"].includes(field) ? (
                                            <textarea name={field} className="form-control" onChange={handleChange} value={formData[field] || ""}
                                            />
                                        ) : ["Duns", "Naics1", "Naics2", "Naics3",
                                            "Naics4", "Naics5", "Nigp1", "Nigp2", "Nigp3", "Nigp4", "Nigp5", "Phone", "Mobile",].includes(field) ? (
                                            <input type='number' name={field} className="form-control" onChange={handleChange} value={formData[field] || ""}
                                            />
                                        ) : field === 'Password' ? (
                                            <input type="password" name={field} className="form-control" onChange={handleChange} value={formData[field]} />
                                        ) : (
                                            <input type={["Email"].includes(field) ? "email" : "text"} name={field} className="form-control" onChange={handleChange} value={formData[field]} />
                                        )}
                                    </div>
                                ))}
                                <div className="col-md-4">
                                    <label className="form-label">Type</label>
                                    <select className="form-select" name="Type" value={formData.Type} onChange={handleChange}>
                                        <option value="2">Type 2</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div className="modal-footer flex-nowrap">
                            <button type="button" className="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" className="btn btn-outline-primary" onClick={handleRegister}>Register</button>
                        </div>

                    </div>
                </div>
            </div>
        </>
    );
}
