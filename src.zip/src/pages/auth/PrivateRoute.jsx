import { Navigate, useLocation } from 'react-router-dom';

export default function PrivateRoute({ children }) {
  const location = useLocation();
  let user;

  try {
    user = JSON.parse(localStorage.getItem('user'));
  } catch {
    user = null;
  }

  return user ? (
    children
  ) : (
    <Navigate to="/" replace state={{ from: location }} />
  );
}
