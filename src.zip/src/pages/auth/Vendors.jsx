import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import LoginRegister from './LoginRegister';

export default function VendorSearch() {
    const { ClientId } = useParams(); // Grab ClientId from URL
    const [adminData, setAdminData] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!ClientId) return;

        const fetchAdminByClientId = async () => {
            setLoading(true);
            setError(null);
            setAdminData(null);

            try {
                const res = await fetch(`https://api.cvcsem.com/api/client-admins/client/${ClientId}`);
                if (!res.ok) throw new Error(`No data found for ClientId: ${ClientId}`);

                const data = await res.json();
                if (data && typeof data === 'object') {
                    setAdminData(data);
                } else {
                    setError('Invalid response format');
                }
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchAdminByClientId();
    }, [ClientId]);

    return (
        <>
            <img
                src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/i/1512c63e-a44e-48e8-92d6-51d80a43cc1e/dezucd8-a4dbad47-4a29-4065-b129-5cdcb64afcf4.png"
                className="img-fluid vendor-baner"
            />

            <div className="container mt-5 border-bottom pb-5">

                {error && <div className="alert alert-danger">{error}</div>}
                {loading && <p>Loading...</p>}

                <div className="row">
                    <div className="col-md-4"></div>
                    <div className="col-md-8"></div>
                </div>
                {adminData && (
                    <div className="row">
                        <div className="col-md-4">
                            <img
                                src={adminData.ProfileImage || 'https://img.freepik.com/premium-vector/neon-frame-template-with-placeholder-blue-incline-light-banner-design-template-glowing-rectangle-signboard_134815-320.jpg'}
                                alt="Admin Profile"
                                className="img-fluid"
                            />
                        </div>
                        <div className="col-md-8">
                            <p>{adminData.AboutUs}</p>
                        </div>
                    </div>
                )}
            </div>

            <LoginRegister/>
        </>
    );
}
